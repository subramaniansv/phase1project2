<?php
require 'config.php';

if (!empty($_SESSION["id"])) {
    $id = $_SESSION["id"];
    $result = mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $id");
    
 
    if ($result && $row = mysqli_fetch_assoc($result)) {
       
        $username = htmlspecialchars($row["username"]); 
    } else {
       
        echo "User not found or query error.";
        exit(); // Stop execution
    }
} else {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <h1>Welcome <?php echo $username; ?></h1>
    <a href="logout.php">Log out</a>
</body>
</html>
